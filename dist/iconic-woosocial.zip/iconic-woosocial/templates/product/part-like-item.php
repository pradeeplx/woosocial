<li class="<?php echo $GLOBALS['iconic_woosocial']->slug; ?>-product-likes__item <?php echo $GLOBALS['iconic_woosocial']->slug; ?>-product-likes__item--<?php echo $user_id; ?>">
    <?php echo $user->avatar_link; ?>
</li>